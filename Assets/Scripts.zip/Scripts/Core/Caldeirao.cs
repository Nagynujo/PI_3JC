using System.Collections.Generic;
using FMODUnity;
using UnityEngine;

public class Caldeirao : MonoBehaviour, IInteractable, IProgressAction
{
    [System.Serializable]
    public class PotionPrefabEntry
    {
        public PotionType tipo;
        [Tooltip("Prefab usado só como referência de mesh/material (nunca é instanciado)")]
        public GameObject prefab;
    }

    [Header("Configuração")]
    public float tempoDeFervura = 5f;
    [Tooltip("Um prefab de poção pra cada PotionType (Fire, Acid, Poison, Invisibility, Cure, Fast) — usado só pra pegar mesh/material na hora de engarrafar")]
    public List<PotionPrefabEntry> potionPrefabs;

    [Tooltip("O mesmo asset de receitas usado pelo livro de receitas (RecipeBookUI)")]
    public LivroDeReceitasSO livroDeReceitas;

    [Tooltip("Pontos (objetos vazios filhos do Caldeirão) onde os 2 ingredientes ficam sentados visualmente. Se deixar vazio, usa deslocamentos padrão.")]
    public List<Transform> pontosDosIngredientes;

    [Header("Efeitos")]
    [Tooltip("Partícula tocada enquanto o caldeirão está fervendo (bolhas/vapor)")]
    public ParticleSystem particulaFervura;

    [Header("Áudio")]
    [Tooltip("Componente StationAudio deste caldeirão (loop da fervura)")]
    public StationAudio audioFervura;

    [Tooltip("Som tocado uma vez quando a garrafa é enchida com a poção (gota)")]
    public EventReference somEngarrafar;

    [Header("Estado (só leitura, pra debug)")]
    public List<IngredientBase> ingredientesDentro = new List<IngredientBase>();
    public bool estaFervendo;
    public bool potionPronta;
    [Range(0f, 1f)] public float progresso;

    private float tempoDecorrido;
    private PotionType potionProntaTipo = PotionType.None;

    public bool EstaEmAndamento => estaFervendo;
    public float Progresso01 => progresso;

    public void Interact(PlayerController player)
    {
        if (potionPronta)
        {
            TentarEngarrafar(player);
            return;
        }

        if (estaFervendo) return;

        IngredientBase held = player.HeldIngredient;

        if (held != null)
        {
            if (held.ehGarrafaVazia)
            {
                Debug.Log("Isso é uma garrafa vazia, não é ingrediente");
                return;
            }

            if (held.potionType != PotionType.None)
            {
                Debug.Log("Isso já é uma poção, não dá pra colocar de volta no caldeirão");
                return;
            }

            if (!held.EstaProcessado)
            {
                Debug.Log("Esse ingrediente ainda não foi moído/cortado");
                return;
            }

            if (ingredientesDentro.Count >= 2)
            {
                Debug.Log("Caldeirão já tem os 2 ingredientes, pode começar a ferver");
                return;
            }

            IngredientBase item = player.ReleaseHand();
            // O SetParent dispara OnTransformParentChanged no IngredientScale,
            // que recalcula a escala usando a IngredientScaleZone do caldeirão.
            item.transform.SetParent(transform);
            PosicionarIngredienteNoCaldeirao(item, ingredientesDentro.Count);
            ingredientesDentro.Add(item);
            Debug.Log($"Caldeirão: {ingredientesDentro.Count}/2 ingredientes");
            return;
        }

        if (ingredientesDentro.Count == 2)
        {
            estaFervendo = true;
            tempoDecorrido = 0f;
            progresso = 0f;

            if (particulaFervura != null)
            {
                particulaFervura.Play();
            }

            if (audioFervura != null)
            {
                audioFervura.Begin();
            }

            Debug.Log("Começou a ferver...");
        }
        else
        {
            Debug.Log($"Precisa de 2 ingredientes (tem {ingredientesDentro.Count})");
        }
    }

    private void TentarEngarrafar(PlayerController player)
    {
        IngredientBase held = player.HeldIngredient;

        if (held == null)
        {
            Debug.Log("Pega uma garrafa vazia pra encher a poção");
            return;
        }

        if (!held.ehGarrafaVazia || held.estaEngarrafada)
        {
            Debug.Log("Precisa estar segurando uma garrafa vazia pra encher");
            return;
        }

        GameObject prefab = GetPrefabFor(potionProntaTipo);
        if (prefab == null)
        {
            Debug.LogWarning($"Nenhum prefab configurado pra poção {potionProntaTipo}");
            return;
        }

        MeshFilter prefabMeshFilter = prefab.GetComponent<MeshFilter>();
        MeshRenderer prefabRenderer = prefab.GetComponent<MeshRenderer>();
        Mesh mesh = prefabMeshFilter != null ? prefabMeshFilter.sharedMesh : null;
        Material mat = prefabRenderer != null ? prefabRenderer.sharedMaterial : null;

        held.PreencherComoPotion(potionProntaTipo, mesh, mat);
        player.RefreshHeldVisual();

        if (!somEngarrafar.IsNull)
        {
            RuntimeManager.PlayOneShot(somEngarrafar, transform.position);
        }

        potionPronta = false;
        potionProntaTipo = PotionType.None;
        Debug.Log("Garrafa engarrafada com a poção!");
    }

    void Update()
    {
        if (!estaFervendo) return;

        tempoDecorrido += Time.deltaTime * EventModifiers.ActionSpeedMultiplier;
        progresso = Mathf.Clamp01(tempoDecorrido / tempoDeFervura);

        if (tempoDecorrido >= tempoDeFervura)
        {
            FinishFervura();
        }
    }

    private void FinishFervura()
    {
        estaFervendo = false;
        progresso = 0f;

        if (particulaFervura != null)
        {
            particulaFervura.Stop();
        }

        PotionType resultado = DeterminePotion();

        if (audioFervura != null)
        {
            audioFervura.End(resultado != PotionType.None);
        }

        foreach (IngredientBase ing in ingredientesDentro)
        {
            Destroy(ing.gameObject);
        }
        ingredientesDentro.Clear();

        if (resultado == PotionType.None)
        {
            Debug.Log("Combinação inválida - poção falhou");
            return;
        }

        potionProntaTipo = resultado;
        potionPronta = true;

        Debug.Log($"Poção pronta: {resultado}! Segura uma garrafa vazia e aperta E pra encher");
    }

    private PotionType DeterminePotion()
    {
        if (ingredientesDentro.Count != 2) return PotionType.None;

        if (livroDeReceitas == null)
        {
            Debug.LogWarning("Caldeirao: nenhum 'Livro De Receitas' configurado. Arraste o asset LivroDeReceitasSO no Inspector.");
            return PotionType.None;
        }

        IngredientKind a = ingredientesDentro[0].kind;
        IngredientKind b = ingredientesDentro[1].kind;

        return livroDeReceitas.Combinar(a, b);
    }

    /// <summary>
    /// Coloca o ingrediente visualmente sentado num dos pontos do caldeirão, em vez de
    /// deixar ele onde a mão do player estava (o que fazia ele "reaparecer" na estação
    /// anterior). 'indice' é a posição na lista (0 = primeiro ingrediente, 1 = segundo).
    /// </summary>
    private void PosicionarIngredienteNoCaldeirao(IngredientBase item, int indice)
    {
        if (pontosDosIngredientes != null && indice < pontosDosIngredientes.Count && pontosDosIngredientes[indice] != null)
        {
            item.transform.position = pontosDosIngredientes[indice].position;
            item.transform.rotation = pontosDosIngredientes[indice].rotation;
        }
        else
        {
            // -----------------------------------------------------------------------
            // [ALTERADO] Fallback agora usa coordenadas de MUNDO.
            //
            // Antes: localPosition = new Vector3(deslocamentoX, 0.5f, 0f);
            //   -> valores LOCAIS eram multiplicados pelo scale do caldeirão,
            //      jogando o ingrediente longe (o "gigante no céu").
            //
            // Agora: 0.5 de altura e +-0.2 de afastamento lateral em unidades de
            //   MUNDO, usando transform.right pra acompanhar a rotação do caldeirão.
            //   Cada ingrediente fica de um lado pra não sobrepor o outro.
            // -----------------------------------------------------------------------
            float deslocamentoX = indice == 0 ? -0.2f : 0.2f;
            item.transform.position = transform.position
                + Vector3.up * 0.5f
                + transform.right * deslocamentoX;
            item.transform.rotation = Quaternion.identity;
        }
    }


    private GameObject GetPrefabFor(PotionType tipo)
    {
        foreach (var entry in potionPrefabs)
        {
            if (entry.tipo == tipo) return entry.prefab;
        }
        return null;
    }
}